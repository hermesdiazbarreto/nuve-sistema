import http from "../api";

class ArticuloServicioDatos {
    obtenerTodo() {
        return http.get("/articulo/");
    }

    obtener(id) {
        return http.get(`/articulo/${id}/`);
    }

    crear(datos) {
        return http.post("/articulo/", datos);
    }

    actualizar(id, datos) {
        return http.put(`/articulo/${id}/`, datos);
    }

    eliminar(id) {
        return http.delete(`/articulo/${id}/`);
    }

    buscarPorPrecio(precio) {
        return http.get(`/articulo?precio=${precio}`);
    }
}

export default new ArticuloServicioDatos();