<template>
    <div class="submit-form">
        <div v-if="!enviar">
            <div class="form-group">
                <label for="nom_articulo">
                    Nombre
                </label>
                <input
                    type="text"
                    class="form-control"
                    id="nom_articulo"
                    required
                    v-model="articulo.nom_articulo"
                    name="nom_articulo"
                />
            </div>

            <div class="form-group">
                <label for="precio">
                    Estado
                </label>
                <input
                    type="number"
                    class="form-control"
                    id="precio"
                    required
                    v-model="articulo.precio"
                    name="precio"
                />
            </div>

            <button @click="guardarArticulo" class="btn btn-success">
                Enviar
            </button>
        </div>

        <div v-else>
            <h4>
                Ha enviado la solicitud con exito.
            </h4>
            <button class="btn btn-success" @click="nuevoArticulo">
                Adicionar
            </button>
        </div>

    </div>

</template>

<script>
    import ArticuloServicioDatos from "../services/ArticuloServicioDatos";

    export default {
        name: "adicionar-articulo",
        data() {
            return {
                articulo: {
                    id: null,
                    nom_articulo: "",
                    precio: 0
                },
                enviar: false
            };
        },

        methods: {
            guardarArticulo() {
                var datos = {
                    nom_articulo: this.articulo.nom_articulo,
                    precio: this.articulo.precio
                };
                ArticuloServicioDatos.crear(datos)
                    .then(response => {
                        this.articulo.id = response.data.id;
                        console.log(response.data);
                        this.enviar = true;
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },

            nuevoArticulo() {
                this.enviar = false;
                this.articulo = {};
            }
        }
    };

</script>

<style>
    .submit-form {
        max-width: 300px;
        margin: auto;
    }
</style>
