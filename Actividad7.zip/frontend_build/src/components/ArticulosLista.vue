<template>
    <div class="list row">
        <div class="col-md-8">
            <div class="input-group mb-3">
                <input
                    type="number"
                    class="form-control"
                    placeholder="Buscar por precio"
                    v-model="precio"
                />
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="button" @click="buscarPrecio">
                        Buscar
                    </button>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <h4>
                Lista de Articulos
            </h4>
            <ul class="list-group">
                <li
                    class="list-group-item"
                    :class="{ active: index == indexActual }"
                    v-for="(articulo, index) in articulos"
                    :key="index"
                    @click="establecerArticuloActivo(articulo, index)"
                >
                    {{ articulo.nom_articulo }}
                </li>
            </ul>
        </div>

        <div class="col-md-6">
            <div v-if="articuloActual">
                <h4>
                    Articulo
                </h4>
                <div>
                    <label>
                        <strong>
                            Nombre:
                        </strong>
                    </label>
                    {{ articuloActual.nom_articulo }}
                </div>
                <div>
                    <label>
                        <strong>
                            Precio:
                        </strong>
                    </label>
                    {{ articuloActual.precio }}
                </div>

                <router-link :to="'/articulos/' + articuloActual.id" class="badge badge-warning">
                    Modificar
                </router-link>
            </div>

            <div v-else>
                <br />
                <p>
                    Dar clic en un articulo...
                </p>
            </div>
        </div>
    </div>
</template>

<script>
    import ArticuloServicioDatos from "../services/ArticuloServicioDatos";
    export default {
        name: "articulos-lista",
        data() {
            return {
                articulos: [],
                articuloActual: null,
                indexActual: -1,
                precio: 0
            };
        },

        methods: {
            recuperarArticulo() {
                ArticuloServicioDatos.obtenerTodo()
                .then(Response => {
                    this.articulos = Response.data;
                    console.log(Response.data);
                })
                .catch(e => {
                    console.log(e);
                });
            },

            actualizarLista() {
                this.articuloActual = null;
                this.indexActual = -1;
            },

            establecerArticuloActivo(articulo, index) {
                this.articuloActual = articulo;
                this.indexActual = articulo ? index : -1;
            },

            buscarPrecio () {
                ArticuloServicioDatos.buscarPorPrecio(this.precio)
                .then(Response => {
                    this.articulos = Response.data;
                    this.establecerArticuloActivo(null);
                    console.log(Response.data);
                })
                .catch(e => {
                    console.log(e)
                });
            }
        },

        mounted() {
            this.recuperarArticulo();
        }
    };

</script>

<style>
    .list {
        text-align: left;
        max-width: 750 px;
        margin: auto;
    }
</style>