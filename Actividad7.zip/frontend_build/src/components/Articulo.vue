<template>
    <div v-if="articuloActual" class="edit-form">
        <h4>
            Articulo
        </h4>
        <form>
            <div class="form-grup">
                <label for="nom_articulo">
                    Nombre
                </label>
                <input
                    type="text"
                    class="form-control"
                    id="nom_articulo"
                    v-model="articuloActual.nom_articulo"
                />
            </div>

            <div class="form-group">
                <label form="precio">
                    Precio
                </label>
                <input
                    type="number"
                    class="form-control"
                    id="precio"
                    v-model="articuloActual.precio"
                />
            </div>
        </form>

        <button class="badge badge-danger mr-2" @click="eliminarArticulo">
            Eliminar
        </button>

        <button type="submit" class="badge badge-sucess" @click="actualizarArticulo">
            Actualizar
        </button>

        <p>
            {{ mensaje }}
        </p>

    </div>

    <div v-else>
        <br>
        <p>
            Click en un articulo...
        </p>
    </div>

</template>

<script>
    import ArticuloServicioDatos from "../services/ArticuloServicioDatos";
    export default {
        name: "unArticulo",

        data() {
            return {
                articuloActual: null, 
                mensaje: ''
            };
        },
        methods: {
            obtenerArticulo(id) {
                ArticuloServicioDatos.obtener(id)
                    .then(Response => {
                        this.articuloActual = Response.data;
                        console.log(Response.data);
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            actualizarArticulo() {
                ArticuloServicioDatos.actualizar(this.articuloActual.id, this.articuloActual)
                    .then(Response => {
                        console.log(Response.data);
                        this.mensaje = "El articulo se ha actualizado";
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            eliminarArticulo() {
                ArticuloServicioDatos.eliminar(this.articuloActual.id)
                    .then(Response => {
                        console.log(Response.data);
                        this.$router.push({ 
                            name: "articulos" 
                            });
                    })
                    .catch(e => {
                        console.log(e);
                    });
                }
            },
        mounted() {
            this.mensaje = '';
            this.obtenerArticulo(this.$route.params.id);
        }
    };
</script>

<style>
    .edit-form {
        max-width: 300px;
        margin: auto;
    }
</style>