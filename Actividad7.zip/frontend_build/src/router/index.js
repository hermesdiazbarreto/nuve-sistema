import { createWebHistory, createRouter } from "vue-router";

const routes = [
    {
        path: "/",
        alias: "/clientes",
        name: "clientes",
        component: () => import("../components/ClientesLista.vue")
    },
    {
        path: "/clientes/:id",
        name: "cliente-detalle",
        component: () => import("../components/Cliente.vue")
    },
    {
        path: "/adicionar-cliente",
        name: "adicionar-cliente",
        component: () => import("../components/AdicionarCliente.vue")
    },
    {
        path: "/",
        alias: "/articulos",
        name: "articulos",
        component: () => import("../components/ArticulosLista.vue")
    },
    {
        path: "/articulos/:id",
        name: "articulo-detalle",
        component: () => import("../components/Articulo.vue")
    },
    {
        path: "/adicionar-articulo",
        name: "/adicionar-articulo",
        component: () => import("../components/AdicionarArticulo.vue")
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

export default router;