from django.shortcuts import render

# Create your views here.
from rest_framework.viewsets import ModelViewSet

from alm.models import Cliente

from alm.serializers import ClienteSerializer
from alm.models import Articulo

from alm.serializers import ArticuloSerializer


class ClienteViewSet (ModelViewSet):
    serializer_class = ClienteSerializer
    queryset = Cliente.objects.all().order_by('id')
    filterset_fields = ['estado', ]
    fields = '__all__'

class ArticuloViewSet (ModelViewSet):
    serializer_class = ArticuloSerializer
    queryset = Articulo.objects.all().order_by('id')
    filterset_fields = ['precio', ]
    fields = '__all__'