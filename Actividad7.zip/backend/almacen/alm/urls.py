from rest_framework.routers import DefaultRouter
from django.urls import path, include

from alm.views import ClienteViewSet
from alm.views import ArticuloViewSet

router = DefaultRouter()
router.register(r'cliente', ClienteViewSet)
router.register(r'articulo', ArticuloViewSet)
urlpatterns = [
    path ('api/', include(router.urls)),

]
